function tic_tac_toe(){ 
   var x = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0]
    ];

  var turn = false;
  var clickCounter = 0;
  var gameOver = false;

  var myTable = document.getElementById("table");
    for(var row = 0; row < myTable.rows.length; row++){
      for(var col = 0; col < myTable.rows[row].cells.length; col++){
        myTable.rows[row].cells[col].onclick = function() {setCellValue(this) };
      }
    }

  function setCellValue(cell) {
    if(gameOver)  {return; }
    if(cell.textContent.charCodeAt() == 160)  {
      if(!turn) {
        cell.textContent = "X";
        document.getElementById("turn").textContent = "Turn: O";
      } else {
        cell.textContent = "O";
        document.getElementById("turn").textContent = "Turn: X";
      }
      turn = !turn;
      clickCounter++;
      fillArray(cell.id);
  }
}

  function fillArray(cellId)  {
      if(turn == 0) 
        x[cellId -1] = 1;
      else {
        x[cellId -1] = 4;
      }

  var score = updateScore();
    if(score != "") {
      document.getElementById("turn").textContent = score;
      gameOver = true;
    }
    else if(clickCounter >= 9){
      document.getElementById("turn").textContent = "Draw, play again!";
      gameOver = true;
    }
  }

    function updateScore(){
      var t = "";
  /* Go through all possible ways to wins
    wins by row */
    if(x[0] + x[1] + x[2] == 3)
      t = "O wins!";
    if(x[0] + x[1] + x[2] == 12)
      t = "X wins!";
    if(x[3] + x[4] + x[5] == 3)
      t = "O wins!";
    if(x[3] + x[4] + x[5] == 12)
      t = "X wins!";
    if(x[6] + x[7] + x[8] == 3)
      t = "O wins!";
    if(x[6] + x[7] + x[8] == 12)
      t = "X wins!";

  //wins by column

    if(x[0] + x[3] + x[6] == 3)
      t = "O wins!";
    if(x[0] + x[3] + x[6] == 12)
      t = "X wins!";
    if(x[1] + x[4] + x[7] == 3)
      t = "O wins!";
    if(x[1] + x[4] + x[7] == 12)
      t = "X wins";
    if(x[2] + x[5] + x[8] == 3)
      t = "O wins!";
    if(x[2] + x[5] + x[8] == 12)
      t = "X wins";

   //wins by diagonal
  
    if(x[0] + x[4] + x[8] == 3)
      t = "O wins!";
    if(x[0] + x[4] + x[8] == 12)  
      t = "X wins!";
    if(x[2] + x[4] + x[6] == 3)
      t = "O wins!";
    if(x[2] + x[4] + x[6] == 12)
      t = "X wins!";
  
      return t;

  }
}

 tic_tac_toe();